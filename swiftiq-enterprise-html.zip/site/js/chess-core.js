/* SwiftIQ chess: full rules (check, checkmate, stalemate, castling, en passant, promotion,
   50-move and insufficient-material draws) plus a small alpha-beta engine that plays Black. */
const BACK = ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r']
export const GLYPH = {
  w: { k: '♔', q: '♕', r: '♖', b: '♗', n: '♘', p: '♙' },
  b: { k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟' },
}
export const NAME = { k: 'king', q: 'queen', r: 'rook', b: 'bishop', n: 'knight', p: 'pawn' }
export const squareName = (c, r) => 'abcdefgh'[c] + (8 - r)

const VAL = { p: 100, n: 320, b: 330, r: 500, q: 900, k: 0 }
const KN = [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]]
const KG = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]
const BD = [[1, 1], [1, -1], [-1, 1], [-1, -1]]
const RD = [[1, 0], [-1, 0], [0, 1], [0, -1]]
const inB = (c, r) => c >= 0 && c < 8 && r >= 0 && r < 8
const other = (c) => (c === 'w' ? 'b' : 'w')

export function initialGame() {
  const board = Array.from({ length: 8 }, () => Array(8).fill(null))
  BACK.forEach((t, c) => {
    board[0][c] = { id: `b-${t}-${c}`, type: t, color: 'b' }
    board[1][c] = { id: `bp-${c}`, type: 'p', color: 'b' }
    board[6][c] = { id: `wp-${c}`, type: 'p', color: 'w' }
    board[7][c] = { id: `w-${t}-${c}`, type: t, color: 'w' }
  })
  return { board, turn: 'w', castle: { wK: true, wQ: true, bK: true, bQ: true }, ep: null, half: 0 }
}

function isAttacked(board, c, r, by) {
  const dir = by === 'w' ? -1 : 1
  for (const dc of [-1, 1]) {
    const pc = c + dc, pr = r - dir
    if (inB(pc, pr)) { const p = board[pr][pc]; if (p && p.color === by && p.type === 'p') return true }
  }
  for (const [dc, dr] of KN) { const x = c + dc, y = r + dr; if (inB(x, y)) { const p = board[y][x]; if (p && p.color === by && p.type === 'n') return true } }
  for (const [dc, dr] of KG) { const x = c + dc, y = r + dr; if (inB(x, y)) { const p = board[y][x]; if (p && p.color === by && p.type === 'k') return true } }
  for (const [dirs, t1] of [[BD, 'b'], [RD, 'r']]) {
    for (const [dc, dr] of dirs) {
      let x = c + dc, y = r + dr
      while (inB(x, y)) {
        const p = board[y][x]
        if (p) { if (p.color === by && (p.type === t1 || p.type === 'q')) return true; break }
        x += dc; y += dr
      }
    }
  }
  return false
}

function findKing(board, color) {
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) { const p = board[r][c]; if (p && p.type === 'k' && p.color === color) return [c, r] }
  return null
}
export function inCheck(g, color) {
  const k = findKing(g.board, color)
  return k ? isAttacked(g.board, k[0], k[1], other(color)) : false
}

/** Pseudo-legal moves (may leave own king in check). allPromo=true generates all four promotions. */
export function genMoves(g, color, allPromo = false) {
  const { board } = g, out = []
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
    const p = board[r][c]
    if (!p || p.color !== color) continue
    const push = (tc, tr, extra = {}) => out.push({ fc: c, fr: r, tc, tr, ...extra })
    if (p.type === 'p') {
      const dir = color === 'w' ? -1 : 1, start = color === 'w' ? 6 : 1, last = color === 'w' ? 0 : 7
      const add = (tc, tr, extra = {}) => {
        if (tr === last) (allPromo ? ['q', 'r', 'b', 'n'] : ['q']).forEach((t) => push(tc, tr, { ...extra, promo: t }))
        else push(tc, tr, extra)
      }
      if (inB(c, r + dir) && !board[r + dir][c]) {
        add(c, r + dir)
        if (r === start && !board[r + 2 * dir][c]) push(c, r + 2 * dir, { dbl: true })
      }
      for (const dc of [-1, 1]) {
        const x = c + dc, y = r + dir
        if (!inB(x, y)) continue
        const t = board[y][x]
        if (t && t.color !== color) add(x, y, { cap: true })
        else if (!t && g.ep && g.ep.c === x && g.ep.r === y) push(x, y, { cap: true, ep: true })
      }
    } else if (p.type === 'n' || p.type === 'k') {
      for (const [dc, dr] of p.type === 'n' ? KN : KG) {
        const x = c + dc, y = r + dr
        if (!inB(x, y)) continue
        const t = board[y][x]
        if (!t || t.color !== color) push(x, y, t ? { cap: true } : {})
      }
      if (p.type === 'k') {
        const row = color === 'w' ? 7 : 0, en = other(color)
        if (c === 4 && r === row && !isAttacked(board, 4, row, en)) {
          if (g.castle[color + 'K'] && !board[row][5] && !board[row][6] && board[row][7]?.type === 'r' && board[row][7].color === color
            && !isAttacked(board, 5, row, en) && !isAttacked(board, 6, row, en)) push(6, row, { castle: 'K' })
          if (g.castle[color + 'Q'] && !board[row][3] && !board[row][2] && !board[row][1] && board[row][0]?.type === 'r' && board[row][0].color === color
            && !isAttacked(board, 3, row, en) && !isAttacked(board, 2, row, en)) push(2, row, { castle: 'Q' })
        }
      }
    } else {
      const dirs = p.type === 'b' ? BD : p.type === 'r' ? RD : [...BD, ...RD]
      for (const [dc, dr] of dirs) {
        let x = c + dc, y = r + dr
        while (inB(x, y)) {
          const t = board[y][x]
          if (!t) push(x, y)
          else { if (t.color !== color) push(x, y, { cap: true }); break }
          x += dc; y += dr
        }
      }
    }
  }
  return out
}

export function applyMove(g, mv) {
  const board = g.board.map((row) => row.slice())
  const p = board[mv.fr][mv.fc]
  const target = board[mv.tr][mv.tc]
  board[mv.fr][mv.fc] = null
  if (mv.ep) board[mv.fr][mv.tc] = null
  board[mv.tr][mv.tc] = mv.promo ? { ...p, type: mv.promo } : p
  if (mv.castle) {
    const row = mv.tr
    if (mv.castle === 'K') { board[row][5] = board[row][7]; board[row][7] = null }
    else { board[row][3] = board[row][0]; board[row][0] = null }
  }
  const castle = { ...g.castle }
  if (p.type === 'k') { castle[p.color + 'K'] = false; castle[p.color + 'Q'] = false }
  const touch = (c, r) => {
    if (r === 7 && c === 0) castle.wQ = false; if (r === 7 && c === 7) castle.wK = false
    if (r === 0 && c === 0) castle.bQ = false; if (r === 0 && c === 7) castle.bK = false
  }
  touch(mv.fc, mv.fr); touch(mv.tc, mv.tr)
  return {
    board, turn: other(g.turn), castle,
    ep: mv.dbl ? { c: mv.fc, r: (mv.fr + mv.tr) / 2 } : null,
    half: p.type === 'p' || target || mv.ep ? 0 : g.half + 1,
  }
}

export function legalMoves(g, allPromo = false) {
  return genMoves(g, g.turn, allPromo).filter((mv) => !inCheck(applyMove(g, mv), g.turn))
}

function insufficient(board) {
  const rest = []
  for (const row of board) for (const p of row) if (p && p.type !== 'k') rest.push(p)
  return rest.length === 0 || (rest.length === 1 && (rest[0].type === 'n' || rest[0].type === 'b'))
}

export function gameStatus(g) {
  const moves = legalMoves(g), chk = inCheck(g, g.turn)
  if (!moves.length) return chk ? 'checkmate' : 'stalemate'
  if (insufficient(g.board)) return 'insufficient'
  if (g.half >= 100) return 'fifty'
  return chk ? 'check' : 'play'
}

/* ---------------- engine ---------------- */
function evaluate(g) {
  let s = 0
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
    const p = g.board[r][c]
    if (!p) continue
    const cen = 3.5 - Math.abs(c - 3.5) + (3.5 - Math.abs(r - 3.5))
    const adv = p.color === 'w' ? 6 - r : r - 1
    const back = p.color === 'w' ? 7 : 0
    let v = VAL[p.type]
    if (p.type === 'p') v += adv * 8 + cen * 2
    else if (p.type === 'n') v += cen * 10
    else if (p.type === 'b') v += cen * 5
    else if (p.type === 'q') v += cen * 2
    else if (p.type === 'k') v += r === back ? (c === 1 || c === 2 || c === 6 ? 25 : 8) : -15
    s += p.color === 'w' ? v : -v
  }
  return g.turn === 'w' ? s : -s
}

function order(g, moves) {
  return moves.map((m) => {
    const t = g.board[m.tr][m.tc], me = g.board[m.fr][m.fc]
    return { m, k: (t ? 10 * VAL[t.type] - VAL[me.type] : 0) + (m.promo ? 800 : 0) + (m.castle ? 30 : 0) }
  }).sort((a, b) => b.k - a.k).map((x) => x.m)
}

function negamax(g, depth, alpha, beta) {
  if (depth === 0) return evaluate(g)
  const moves = order(g, genMoves(g, g.turn))
  let best = -Infinity
  for (const mv of moves) {
    const t = g.board[mv.tr][mv.tc]
    if (t && t.type === 'k') return 100000 + depth
    const sc = -negamax(applyMove(g, mv), depth - 1, -beta, -alpha)
    if (sc > best) best = sc
    if (best > alpha) alpha = best
    if (alpha >= beta) break
  }
  return best === -Infinity ? 0 : best
}

export const LEVELS = { easy: 1, medium: 3, hard: 4 }
export function bestMove(g, level = 'medium') {
  const moves = order(g, legalMoves(g))
  if (!moves.length) return null
  const depth = LEVELS[level] ?? 3
  const slack = level === 'easy' ? 120 : 8 // moves within `slack` of the best are all acceptable, for variety
  const scored = []
  let alpha = -Infinity
  for (const mv of moves) {
    const sc = -negamax(applyMove(g, mv), depth - 1, -Infinity, -alpha)
    scored.push({ mv, sc })
    // window keeps every move within `slack` of the best exact; worse moves fail low and are discarded
    if (sc - slack - 1 > alpha) alpha = sc - slack - 1
  }
  const top = Math.max(...scored.map((x) => x.sc))
  const pool = scored.filter((x) => x.sc >= top - slack)
  return pool[Math.floor(Math.random() * pool.length)].mv
}

/* ---------------- game controller used by the page ---------------- */
const MESSAGES = {
  play: 'Your move (White).', check: 'Check! Protect your king.',
  checkmate: '', stalemate: 'Stalemate. The game is a draw.', insufficient: 'Draw: not enough pieces left to checkmate.', fifty: 'Draw by the 50-move rule.',
}

export function createChess() {
  let g = initialGame(), sel = null, targets = [], last = null, promo = null, thinking = false, history = [], token = 0, level = 'medium'
  const subs = new Set()

  const pieces = () => {
    const out = []
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) { const p = g.board[r][c]; if (p) out.push({ ...p, c, r }) }
    return out
  }
  const snapshot = () => {
    const st = gameStatus(g)
    const over = ['checkmate', 'stalemate', 'insufficient', 'fifty'].includes(st)
    let status = MESSAGES[st]
    if (st === 'checkmate') status = g.turn === 'b' ? 'Checkmate! You win. Well played.' : 'Checkmate. SwiftIQ Black wins this one.'
    else if (thinking) status = 'Black is thinking…'
    else if (promo) status = 'Choose a piece for your pawn.'
    const k = inCheck(g, g.turn) ? findKing(g.board, g.turn) : null
    return { pieces: pieces(), sel, targets, last, status, over, thinking, promo: !!promo, check: k ? { c: k[0], r: k[1] } : null, canUndo: history.length > 0 && !thinking, level }
  }
  const emit = () => { const s = snapshot(); subs.forEach((f) => f(s)) }

  const finishPlayerMove = (mv) => {
    history.push({ g, last })
    g = applyMove(g, mv); sel = null; targets = []; promo = null
    last = { from: { c: mv.fc, r: mv.fr }, to: { c: mv.tc, r: mv.tr } }
    const st = gameStatus(g)
    if (['checkmate', 'stalemate', 'insufficient', 'fifty'].includes(st)) { emit(); return }
    thinking = true; emit()
    const my = ++token
    setTimeout(() => {
      if (my !== token) return
      const reply = bestMove(g, level)
      if (reply) { g = applyMove(g, reply); last = { from: { c: reply.fc, r: reply.fr }, to: { c: reply.tc, r: reply.tr } } }
      thinking = false; emit()
    }, 450)
  }

  return {
    get state() { return snapshot() },
    subscribe(f) { subs.add(f); f(snapshot()); return () => subs.delete(f) },
    click(c, r) {
      if (thinking || promo || g.turn !== 'w' || snapshot().over) return
      const here = g.board[r][c]
      const hit = targets.find((t) => t.c === c && t.r === r)
      if (sel && hit) {
        const mv = hit.mv
        if (mv.promo) { promo = mv; emit(); return }
        finishPlayerMove(mv); return
      }
      if (here && here.color === 'w' && here.id !== sel) {
        sel = here.id
        targets = legalMoves(g).filter((m) => m.fc === c && m.fr === r).map((m) => ({ c: m.tc, r: m.tr, cap: !!m.cap, mv: m }))
      } else { sel = null; targets = [] }
      emit()
    },
    choosePromotion(type) { if (promo) finishPlayerMove({ ...promo, promo: type }) },
    undo() {
      if (thinking || !history.length) return
      const h = history.pop(); g = h.g; last = h.last; sel = null; targets = []; promo = null; token++; emit()
    },
    reset() { token++; g = initialGame(); sel = null; targets = []; last = null; promo = null; thinking = false; history = []; emit() },
    setLevel(l) { if (LEVELS[l]) { level = l; emit() } },
  }
}
