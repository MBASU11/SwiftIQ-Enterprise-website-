import * as THREE from 'three'

/** Small helper that sets up renderer, camera, resize, pointer and a pausable render loop. */
export function createStage(container, { low, reduced, fov = 40, camPos = [0, 0, 7], lookAt = [0, 0, 0] }) {
  const renderer = new THREE.WebGLRenderer({ antialias: !low, alpha: true, powerPreference: 'high-performance' })
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, low ? 1.25 : 1.75))
  renderer.toneMapping = THREE.ACESFilmicToneMapping
  renderer.domElement.className = 'three'
  renderer.domElement.setAttribute('aria-hidden', 'true')
  container.prepend(renderer.domElement)

  const scene = new THREE.Scene()
  const camera = new THREE.PerspectiveCamera(fov, 1, 0.1, 100)
  camera.position.set(...camPos)
  camera.lookAt(...lookAt)

  const pointer = { x: 0, y: 0 }
  window.addEventListener('pointermove', (e) => {
    const r = container.getBoundingClientRect()
    pointer.x = Math.max(-1, Math.min(1, ((e.clientX - r.left) / r.width) * 2 - 1))
    pointer.y = Math.max(-1, Math.min(1, -(((e.clientY - r.top) / r.height) * 2 - 1)))
  }, { passive: true })

  const frameCbs = [], resizeCbs = []
  const render = () => renderer.render(scene, camera)
  const resize = () => {
    const w = container.clientWidth, h = container.clientHeight
    if (!w || !h) return
    renderer.setSize(w, h, false)
    camera.aspect = w / h
    camera.updateProjectionMatrix()
    resizeCbs.forEach((f) => f(w, h))
    render()
  }
  new ResizeObserver(resize).observe(container)

  const clock = new THREE.Clock()
  let visible = true, running = false
  const loop = () => {
    if (!visible || document.hidden || reduced) { running = false; return }
    running = true
    const dt = Math.min(clock.getDelta(), 0.05), t = clock.elapsedTime
    frameCbs.forEach((f) => f(dt, t))
    render()
    requestAnimationFrame(loop)
  }
  new IntersectionObserver((e) => {
    visible = e[0].isIntersecting
    if (visible && !running && !reduced) { clock.getDelta(); loop() }
  }, { rootMargin: '100px' }).observe(container)

  document.addEventListener('visibilitychange', () => { if (!document.hidden && visible && !running && !reduced) { clock.getDelta(); loop() } })
  resize()
  if (!reduced) loop()

  return { THREE, renderer, scene, camera, pointer, render, resize,
    onFrame: (f) => frameCbs.push(f), onResize: (f) => resizeCbs.push(f) }
}

export const mat = (color, opts = {}) => new THREE.MeshStandardMaterial({ color, ...opts })
export const basic = (color, opts = {}) => new THREE.MeshBasicMaterial({ color, toneMapped: false, ...opts })
export function mesh(geo, material, pos = [0, 0, 0], rot = [0, 0, 0]) {
  const m = new THREE.Mesh(geo, material); m.position.set(...pos); m.rotation.set(...rot); return m
}
