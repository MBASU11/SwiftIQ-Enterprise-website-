import * as THREE from 'three'
import { createStage, mat, basic, mesh } from './stage.js'
import { makeDashboardTexture, makeSparkles } from './canvasArt.js'

export function startHero(container, { low, reduced }) {
  const s = createStage(container, { low, reduced, fov: 40, camPos: [0, 0.2, 7.5] })
  const { scene, pointer } = s
  const lerp = THREE.MathUtils.lerp

  scene.add(new THREE.AmbientLight(0xffffff, 0.5))
  const dir = new THREE.DirectionalLight(0xf5f7ff, 1.4); dir.position.set(4, 6, 4); scene.add(dir)
  const violet = new THREE.PointLight(0x8b5cf6, 30, 16); violet.position.set(-5, 2, -3); scene.add(violet)
  const cyan = new THREE.PointLight(0x00e5ff, 34, 14); cyan.position.set(0, 1, 3.5); scene.add(cyan)

  const rig = new THREE.Group(); scene.add(rig)

  // --- Emblem: the real SwiftIQ logo on stacked translucent layers for a glassy depth
  const tex = new THREE.TextureLoader().load('assets/emblem.png', () => s.render())
  tex.colorSpace = THREE.SRGBColorSpace
  const W = 3.4, H = W * (300 / 380)
  const emblem = new THREE.Group(); emblem.position.y = 0.45; rig.add(emblem)
  const spin = new THREE.Group(); emblem.add(spin)
  ;[-0.16, -0.12, -0.08, -0.04].forEach((z, i) => {
    spin.add(mesh(new THREE.PlaneGeometry(W, H), new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0.16 + i * 0.05, color: 0x00e5ff, depthWrite: false, toneMapped: false }), [0, 0, z]))
  })
  spin.add(mesh(new THREE.PlaneGeometry(W, H), new THREE.MeshBasicMaterial({ map: tex, transparent: true, alphaTest: 0.04, side: THREE.DoubleSide, toneMapped: false })))
  spin.add(mesh(new THREE.PlaneGeometry(W, H), new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0.28, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }), [0, 0, 0.03]))

  // --- Platform
  const platform = new THREE.Group(); platform.position.y = -1.75; rig.add(platform)
  platform.add(mesh(new THREE.CylinderGeometry(2.3, 2.45, 0.14, 64), mat(0x0b1225, { metalness: 0.9, roughness: 0.25 })))
  platform.add(mesh(new THREE.CircleGeometry(2.1, 64), mat(0x0e1a3a, { metalness: 0.8, roughness: 0.2, emissive: 0x1261ff, emissiveIntensity: 0.18 }), [0, 0.075, 0], [-Math.PI / 2, 0, 0]))
  platform.add(mesh(new THREE.TorusGeometry(2.3, 0.025, 12, 128), basic(0x00e5ff), [0, 0.09, 0], [-Math.PI / 2, 0, 0]))
  const ringGroup = new THREE.Group(); ringGroup.position.y = 0.1; ringGroup.rotation.x = -Math.PI / 2; platform.add(ringGroup)
  ringGroup.add(mesh(new THREE.TorusGeometry(1.7, 0.018, 8, 96, Math.PI * 1.3), basic(0x1261ff)))
  ringGroup.add(mesh(new THREE.TorusGeometry(1.25, 0.014, 8, 96, Math.PI * 0.8), basic(0x8b5cf6), [0, 0, 0], [0, 0, Math.PI]))
  platform.add(mesh(new THREE.CylinderGeometry(1.9, 2.1, 3.4, 48, 1, true), new THREE.MeshBasicMaterial({ color: 0x1261ff, transparent: true, opacity: 0.07, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }), [0, 1.7, 0]))

  // --- Light trails
  const trails = new THREE.Group(); trails.rotation.set(0.35, 0.2, 0); rig.add(trails)
  const trailMeshes = [[2.7, 0x00e5ff, 1.1], [3.1, 0x1261ff, 0.9], [3.5, 0x8b5cf6, 0.7]].map(([r, c, arc], i) => {
    const m = mesh(new THREE.TorusGeometry(r, 0.014, 8, 128, arc * Math.PI), basic(c, { transparent: true, opacity: 0.85 }), [0, 0, 0], [0, 0, i * 2])
    trails.add(m); return m
  })

  // --- Laptop with a canvas dashboard
  const laptopWrap = new THREE.Group(); rig.add(laptopWrap)
  const laptop = new THREE.Group(); laptop.rotation.set(0.05, -0.5, 0); laptopWrap.add(laptop)
  const metal = () => mat(0x8d97ad, { metalness: 0.95, roughness: 0.3 })
  laptop.add(mesh(new THREE.BoxGeometry(2.3, 0.07, 1.5), metal()))
  laptop.add(mesh(new THREE.BoxGeometry(1.9, 0.01, 0.8), mat(0x10182e, { metalness: 0.6, roughness: 0.5 }), [0, 0.04, 0.1]))
  const hinge = new THREE.Group(); hinge.position.set(0, 0.04, -0.72); hinge.rotation.x = -0.32; laptop.add(hinge)
  hinge.add(mesh(new THREE.BoxGeometry(2.3, 1.45, 0.06), metal(), [0, 0.72, 0]))
  hinge.add(mesh(new THREE.PlaneGeometry(2.14, 1.3), basic(0xffffff, { map: makeDashboardTexture() }), [0, 0.72, 0.035]))

  // --- Floating objects
  const floats = []
  const addFloat = (m, speed, amp) => { floats.push({ m, y: m.position.y, speed, amp, ph: Math.random() * 6 }); rig.add(m); return m }
  const objs = {
    ico: addFloat(mesh(new THREE.IcosahedronGeometry(0.38, 0), mat(0x1261ff, { wireframe: true, emissive: 0x1261ff, emissiveIntensity: 1 }), [-3.4, 1.4, -1]), 2, 0.2),
    tor: addFloat(mesh(new THREE.TorusGeometry(0.3, 0.07, 12, 32), mat(0x8b5cf6, { metalness: 0.8, roughness: 0.2, emissive: 0x8b5cf6, emissiveIntensity: 0.4 }), [-2.8, -1.2, 0.8], [0.8, 0.4, 0]), 1.6, 0.25),
    oct: addFloat(mesh(new THREE.OctahedronGeometry(0.35, 0), mat(0x00e5ff, { wireframe: true, emissive: 0x00e5ff, emissiveIntensity: 1 }), [3.2, 2, -1.2]), 2.4, 0.2),
    box: addFloat(mesh(new THREE.BoxGeometry(0.32, 0.32, 0.32), mat(0xf5f7ff, { metalness: 0.9, roughness: 0.15 }), [1.7, 2.4, 0.2], [0.5, 0.5, 0]), 1.8, 0.22),
  }
  const sparkles = makeSparkles(low ? 35 : 110, [11, 6, 6], 0x00e5ff, low ? 0.07 : 0.09); rig.add(sparkles)

  // --- Responsive layout
  const baseX = { ico: -3.4, tor: -2.8, oct: 3.2, box: 1.7 }
  let narrow = false
  s.onResize((w, h) => {
    const vh = 2 * Math.tan((40 * Math.PI) / 360) * 7.5, vw = vh * (w / h)
    narrow = vw < 7
    rig.position.set(narrow ? 0 : vw * 0.17, narrow ? 0.2 : 0, 0)
    rig.scale.setScalar(narrow ? 0.72 : 1)
    laptopWrap.position.set(...(narrow ? [1.5, -1.5, 1.3] : [2.6, -1.35, 1]))
    laptopWrap.scale.setScalar(narrow ? 0.62 : 0.78)
    Object.entries(objs).forEach(([k, m]) => { m.position.x = baseX[k] * (narrow ? 0.7 : 1) })
  })
  s.resize()

  s.onFrame((dt, t) => {
    spin.rotation.y = Math.sin(t * 0.45) * 0.55
    ringGroup.rotation.z += dt * 0.35
    trailMeshes.forEach((m, i) => { m.rotation.z += dt * (0.5 + i * 0.25) * (i % 2 ? -1 : 1) })
    floats.forEach((f) => { f.m.position.y = f.y + Math.sin(t * f.speed + f.ph) * f.amp; f.m.rotation.y += dt * 0.4 })
    laptopWrap.position.y += Math.sin(t * 1.4) * 0.0015
    sparkles.rotation.y += dt * 0.02; sparkles.position.y = Math.sin(t * 0.3) * 0.15
    rig.rotation.y = lerp(rig.rotation.y, pointer.x * 0.22, 0.05)
    rig.rotation.x = lerp(rig.rotation.x, -pointer.y * 0.1, 0.05)
    cyan.position.x = lerp(cyan.position.x, pointer.x * 4, 0.08)
    cyan.position.y = lerp(cyan.position.y, pointer.y * 3 + 1, 0.08)
  })

  container.querySelector('.hero__fallback')?.remove()
  s.render()
}
