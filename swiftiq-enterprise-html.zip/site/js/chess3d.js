import * as THREE from 'three'
import { createStage, mat, mesh } from './stage.js'

const pos = (c, r) => [c - 3.5, r - 3.5]

function buildPiece(type, white) {
  const m = new THREE.MeshStandardMaterial({
    color: white ? 0xeef1fb : 0x171a2b, metalness: white ? 0.15 : 0.7, roughness: white ? 0.35 : 0.22,
    emissive: white ? 0x000000 : 0x1b1250, emissiveIntensity: 0.35,
  })
  const g = new THREE.Group()
  const add = (geo, p = [0, 0, 0], r = [0, 0, 0], sc = [1, 1, 1]) => { const x = mesh(geo, m, p, r); x.scale.set(...sc); g.add(x) }
  const cyl = (rt, rb, h) => new THREE.CylinderGeometry(rt, rb, h, 20)
  const ball = (rad) => new THREE.SphereGeometry(rad, 20, 16)
  add(new THREE.CylinderGeometry(0.3, 0.34, 0.12, 24), [0, 0.06, 0])
  const body = (rt, rb, h) => add(cyl(rt, rb, h), [0, 0.12 + h / 2, 0])
  switch (type) {
    case 'p': body(0.1, 0.2, 0.34); add(ball(0.14), [0, 0.58, 0]); break
    case 'r':
      body(0.18, 0.22, 0.46); add(new THREE.CylinderGeometry(0.27, 0.2, 0.14, 8), [0, 0.64, 0])
      for (let i = 0; i < 4; i++) add(new THREE.BoxGeometry(0.1, 0.1, 0.1), [Math.cos((i * Math.PI) / 2 + 0.78) * 0.2, 0.76, Math.sin((i * Math.PI) / 2 + 0.78) * 0.2])
      break
    case 'n': body(0.15, 0.22, 0.34); add(new THREE.BoxGeometry(0.22, 0.4, 0.3), [0, 0.6, 0.04], [0.25, 0, 0]); add(new THREE.BoxGeometry(0.18, 0.16, 0.26), [0, 0.58, 0.28], [0.5, 0, 0]); break
    case 'b': body(0.1, 0.22, 0.5); add(ball(0.16), [0, 0.76, 0], [0, 0, 0], [1, 1.4, 1]); add(ball(0.05), [0, 0.99, 0]); break
    case 'q': body(0.12, 0.24, 0.62); add(new THREE.TorusGeometry(0.2, 0.04, 8, 24), [0, 0.78, 0], [Math.PI / 2, 0, 0]); add(ball(0.15), [0, 0.92, 0]); add(ball(0.06), [0, 1.1, 0]); break
    case 'k': body(0.13, 0.25, 0.66); add(ball(0.16), [0, 0.86, 0]); add(new THREE.BoxGeometry(0.07, 0.3, 0.07), [0, 1.08, 0]); add(new THREE.BoxGeometry(0.22, 0.07, 0.07), [0, 1.1, 0]); break
  }
  g.userData.mat = m
  g.userData.type = type
  g.userData.white = white
  g.rotation.y = white ? 0 : Math.PI
  return g
}

export function startChess3D(container, chess, { low, reduced }) {
  const s = createStage(container, { low, reduced, fov: 36, camPos: [0, 7.4, 8.4], lookAt: [0, 0, 0.3] })
  const { scene, pointer } = s
  scene.add(new THREE.AmbientLight(0xffffff, 0.45))
  const spot = new THREE.SpotLight(0xffffff, 180, 0, 0.6, 0.7); spot.position.set(0, 10, 4); scene.add(spot)
  const l1 = new THREE.PointLight(0x8b5cf6, 50, 20); l1.position.set(-7, 3, -3); scene.add(l1)
  const l2 = new THREE.PointLight(0x1261ff, 50, 20); l2.position.set(7, 3, 3); scene.add(l2)

  const rig = new THREE.Group(); scene.add(rig)
  rig.add(mesh(new THREE.BoxGeometry(8.5, 0.16, 8.5), mat(0x0b1225, { metalness: 0.9, roughness: 0.25 }), [0, -0.14, 0]))
  rig.add(mesh(new THREE.PlaneGeometry(30, 30), mat(0x080d1c, { metalness: 0.8, roughness: 0.4 }), [0, -0.24, 0], [-Math.PI / 2, 0, 0]))

  const squares = []
  for (let i = 0; i < 64; i++) {
    const c = i % 8, r = Math.floor(i / 8), [x, z] = pos(c, r)
    const m = mesh(new THREE.BoxGeometry(1, 0.1, 1), mat((c + r) % 2 === 0 ? 0xd7dcec : 0x1a2650, { metalness: 0.3, roughness: 0.35, emissive: 0x00e5ff, emissiveIntensity: 0 }), [x, -0.05, z])
    m.userData = { c, r }; rig.add(m); squares.push(m)
  }

  const groups = new Map()
  let state = chess.state
  const sync = (st) => {
    state = st
    const byId = new Map(st.pieces.map((p) => [p.id, p]))
    groups.forEach((g, id) => {
      const p = byId.get(id)
      if (!p || g.userData.type !== p.type) { rig.remove(g); groups.delete(id) } // captured, or promoted (rebuilt below)
    })
    st.pieces.forEach((p) => {
      if (!groups.has(p.id)) {
        const old = groups.get(p.id)
        const g = buildPiece(p.type, p.color === 'w'); const [x, z] = pos(p.c, p.r)
        g.position.set(x, 0, z); g.userData.id = p.id; rig.add(g); groups.set(p.id, g)
      }
    })
    const sp = st.pieces.find((p) => p.id === st.sel)
    squares.forEach((q) => {
      const { c, r } = q.userData
      let hex = 0, k = 0
      if (st.last && ((st.last.from.c === c && st.last.from.r === r) || (st.last.to.c === c && st.last.to.r === r))) { hex = 0x8b5cf6; k = 0.25 }
      const t = st.targets && st.targets.find((x) => x.c === c && x.r === r)
      if (t) { hex = t.cap ? 0xff4d6d : 0x00ff9d; k = 0.5 }
      if (sp && sp.c === c && sp.r === r) { hex = 0x00e5ff; k = 0.65 }
      if (st.check && st.check.c === c && st.check.r === r) { hex = 0xff3355; k = 0.8 }
      q.material.emissive.setHex(hex); q.material.emissiveIntensity = k
    })
    s.render()
  }
  const unsub = chess.subscribe(sync)

  const apply = (k) => {
    state.pieces.forEach((p) => {
      const g = groups.get(p.id); if (!g) return
      const [tx, tz] = pos(p.c, p.r), sel = p.id === state.sel
      g.position.x = THREE.MathUtils.lerp(g.position.x, tx, k)
      g.position.z = THREE.MathUtils.lerp(g.position.z, tz, k)
      g.position.y = THREE.MathUtils.lerp(g.position.y, sel ? 0.35 : 0, k)
      const m = g.userData.mat
      m.emissive.setHex(sel ? 0x00e5ff : g.userData.white ? 0x000000 : 0x1b1250); m.emissiveIntensity = sel ? 0.7 : 0.35
    })
  }
  s.onFrame(() => {
    apply(0.18)
    rig.rotation.y = THREE.MathUtils.lerp(rig.rotation.y, pointer.x * 0.25, 0.04)
  })
  if (reduced) { const base = sync; chess.subscribe((st) => { base(st); apply(1); s.render() }) }

  // Click / tap picking
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2()
  s.renderer.domElement.addEventListener('click', (e) => {
    const r = s.renderer.domElement.getBoundingClientRect()
    ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -(((e.clientY - r.top) / r.height) * 2 - 1))
    ray.setFromCamera(ndc, s.camera)
    const hit = ray.intersectObjects([...squares, ...groups.values()], true)[0]
    if (!hit) return
    let o = hit.object
    while (o && o.userData.c === undefined && o.userData.id === undefined) o = o.parent
    if (!o) return
    if (o.userData.id !== undefined) { const p = state.pieces.find((x) => x.id === o.userData.id); if (p) chess.click(p.c, p.r) }
    else chess.click(o.userData.c, o.userData.r)
  })
  return unsub
}
