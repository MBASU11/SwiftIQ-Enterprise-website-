import * as THREE from 'three'

function rr(ctx, x, y, w, h, r) {
  ctx.beginPath(); ctx.moveTo(x + r, y)
  ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r)
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath()
}
const tex = (c) => { const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t }

export function makeDashboardTexture() {
  const w = 1024, h = 640, c = document.createElement('canvas'); c.width = w; c.height = h
  const ctx = c.getContext('2d')
  const g = ctx.createLinearGradient(0, 0, w, h); g.addColorStop(0, '#0B1225'); g.addColorStop(1, '#101a38')
  ctx.fillStyle = g; ctx.fillRect(0, 0, w, h)
  ctx.fillStyle = '#0a1020'; ctx.fillRect(0, 0, 150, h)
  ctx.fillStyle = '#00E5FF'; ctx.font = '700 22px sans-serif'; ctx.fillText('SwiftIQ', 24, 46)
  ;['Overview', 'Customers', 'Sales', 'Invoices', 'Reports', 'Settings'].forEach((t, i) => {
    if (i === 0) { ctx.fillStyle = 'rgba(18,97,255,.35)'; rr(ctx, 12, 78, 126, 38, 10); ctx.fill() }
    ctx.fillStyle = i === 0 ? '#F5F7FF' : '#A7B4CC'; ctx.font = '500 17px sans-serif'; ctx.fillText(t, 30, 103 + i * 52)
  })
  ctx.fillStyle = '#F5F7FF'; ctx.font = '700 28px sans-serif'; ctx.fillText('Business overview', 180, 52)
  ;[['Sales', 'KES 482K', '#1261FF'], ['Customers', '1,284', '#00E5FF'], ['Invoices', '96', '#8B5CF6']].forEach(([k, v, col], i) => {
    const x = 180 + i * 272
    ctx.fillStyle = 'rgba(255,255,255,.06)'; rr(ctx, x, 80, 252, 110, 16); ctx.fill(); ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.stroke()
    ctx.fillStyle = '#A7B4CC'; ctx.font = '500 17px sans-serif'; ctx.fillText(k, x + 20, 112)
    ctx.fillStyle = '#F5F7FF'; ctx.font = '700 36px sans-serif'; ctx.fillText(v, x + 20, 162)
  })
  ctx.fillStyle = 'rgba(255,255,255,.05)'; rr(ctx, 180, 214, 520, 380, 18); ctx.fill()
  ctx.strokeStyle = 'rgba(255,255,255,.08)'; ctx.lineWidth = 1
  for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.moveTo(204, 262 + i * 62); ctx.lineTo(676, 262 + i * 62); ctx.stroke() }
  const pts = [0.2, 0.34, 0.28, 0.5, 0.45, 0.66, 0.6, 0.82, 0.9]
  ctx.beginPath(); pts.forEach((p, i) => { const x = 210 + i * 58, y = 560 - p * 280; i ? ctx.lineTo(x, y) : ctx.moveTo(x, y) })
  ctx.strokeStyle = '#00E5FF'; ctx.lineWidth = 5; ctx.lineJoin = 'round'; ctx.stroke()
  ctx.lineTo(210 + 8 * 58, 570); ctx.lineTo(210, 570); ctx.closePath()
  const fg = ctx.createLinearGradient(0, 260, 0, 570); fg.addColorStop(0, 'rgba(0,229,255,.35)'); fg.addColorStop(1, 'rgba(0,229,255,0)')
  ctx.fillStyle = fg; ctx.fill()
  ctx.fillStyle = 'rgba(255,255,255,.05)'; rr(ctx, 720, 214, 284, 380, 18); ctx.fill()
  ;[0.5, 0.8, 0.35, 0.95, 0.6].forEach((p, i) => {
    const bg = ctx.createLinearGradient(0, 560 - p * 260, 0, 560); bg.addColorStop(0, '#8B5CF6'); bg.addColorStop(1, '#1261FF')
    ctx.fillStyle = bg; rr(ctx, 746 + i * 50, 560 - p * 260, 32, p * 260, 8); ctx.fill()
  })
  return tex(c)
}

export function makeBlocksTexture() {
  const w = 768, h = 480, c = document.createElement('canvas'); c.width = w; c.height = h
  const ctx = c.getContext('2d')
  ctx.fillStyle = '#0d1530'; ctx.fillRect(0, 0, w, h); ctx.fillStyle = '#080D1C'; ctx.fillRect(0, 0, 200, h)
  const palette = ['#8B5CF6', '#1261FF', '#00B8D4', '#F59E0B']
  ;['Events', 'Motion', 'Sensing', 'Control'].forEach((t, i) => {
    ctx.fillStyle = palette[i]; ctx.beginPath(); ctx.arc(30, 44 + i * 56, 10, 0, 7); ctx.fill()
    ctx.fillStyle = '#F5F7FF'; ctx.font = '600 20px sans-serif'; ctx.fillText(t, 54, 51 + i * 56)
  })
  ;[['when  ▶  clicked', 250, 50, 0], ['forever', 250, 104, 3], ['if  distance < 10', 280, 158, 2], ['turn  ⟳  90°', 310, 212, 1], ['move  10  steps', 280, 266, 1], ['set  motor  speed  60', 250, 330, 1]].forEach(([t, x, y, p]) => {
    ctx.fillStyle = palette[p]; rr(ctx, x, y, 400, 42, 10); ctx.fill()
    ctx.fillStyle = '#fff'; ctx.font = '700 20px sans-serif'; ctx.fillText(t, x + 16, y + 28)
  })
  return tex(c)
}

export function makeGlowSprite() {
  const c = document.createElement('canvas'); c.width = c.height = 64
  const x = c.getContext('2d'); const g = x.createRadialGradient(32, 32, 0, 32, 32, 32)
  g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.35, 'rgba(255,255,255,.6)'); g.addColorStop(1, 'rgba(255,255,255,0)')
  x.fillStyle = g; x.fillRect(0, 0, 64, 64)
  return new THREE.CanvasTexture(c)
}

export function makeSymbolTexture(text, color) {
  const c = document.createElement('canvas'); c.width = 256; c.height = 128
  const x = c.getContext('2d'); x.font = '700 80px monospace'; x.textAlign = 'center'; x.textBaseline = 'middle'
  x.shadowColor = color; x.shadowBlur = 18; x.fillStyle = color; x.fillText(text, 128, 64)
  return tex(c)
}

export function makeSparkles(count, box, color, size) {
  const pos = new Float32Array(count * 3)
  for (let i = 0; i < count; i++) { pos[i * 3] = (Math.random() - 0.5) * box[0]; pos[i * 3 + 1] = (Math.random() - 0.5) * box[1]; pos[i * 3 + 2] = (Math.random() - 0.5) * box[2] }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3))
  const mat = new THREE.PointsMaterial({ size, color, map: makeGlowSprite(), transparent: true, opacity: 0.85, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true })
  return new THREE.Points(geo, mat)
}
