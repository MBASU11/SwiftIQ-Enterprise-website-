export const BRAND = {
  phoneTel: '+254742210099',
  whatsapp: '254742210099', // Kenya country code + number without the leading 0
  email: 'swiftiqenterprise@gmail.com',
}

export const SERVICE_OPTIONS = [
  'Website Development', 'Graphic Design', 'Application Development', 'Business Automation', 'CCTV Solutions',
  'Laptops and Computers', 'SwiftIQ EduFlow', 'SwiftIQ Business Assistant', 'SwiftIQ POS', 'Coding & Robotics Training', 'Chess Training',
]

const st = 'fill="none" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"'
const svg = (inner) => `<svg viewBox="0 0 160 110" aria-hidden="true">${inner}</svg>`

export const SERVICES = [
  { title: 'Website Development', text: 'Business websites, portfolio websites, school websites, landing pages, domain setup, and hosting.', pos: 'center',
    images: ['assets/services/website-desk.webp', 'assets/graphic/website-flyer.webp'] },
  { title: 'Graphic Design', text: 'Logo design, brand identity, marketing posters, promotional graphics, and social media designs.', pos: 'top',
    images: ['assets/graphic/website-flyer.webp', 'assets/logo.png'] },
  { title: 'Application Development', text: 'Custom web applications, mobile applications, and tailored software solutions.', pos: 'center',
    images: ['assets/services/app-dev-desk.webp', 'assets/services/app-dev-laptops.webp'] },
  { title: 'Business Automation', text: 'Digital workflows, business management tools, process automation, and productivity solutions.', pos: 'center',
    images: ['assets/services/automation-hub.webp'] },
  { title: 'CCTV Solutions', text: 'CCTV supply, installation coordination, and security technology solutions.', pos: 'center',
    images: ['assets/services/cctv-control-room.webp', 'assets/services/cctv-monitoring.webp', 'assets/services/cctv-cameras.webp'] },
  { title: 'Laptops and Computers', text: 'Computer sales, hardware recommendations, and technology solutions for businesses, schools, and individuals.', pos: 'center',
    images: ['assets/services/laptop-macbook.webp', 'assets/services/laptops-lineup.webp', 'assets/services/laptop-dell.webp'] },
]

export const ROBO_PROGRAMMES = [
  { icon: '</>', title: 'Coding and Programming', items: ['Scratch programming', 'Python programming fundamentals', 'Programming logic and problem-solving', 'Interactive coding projects'] },
  { icon: '🤖', title: 'Robotics Education', items: ['Robot assembly and construction', 'Motors, sensors, and electronic components', 'Robotic programming and control', 'Practical robotics challenges'] },
  { icon: '🚀', title: 'Hands-on Innovation Projects', items: ['Building and programming robots', 'Developing practical technology projects', 'Exploring sensors and automation', 'Encouraging creativity, experimentation, and problem-solving'] },
  { icon: '🏫', title: 'School Coding & Robotics Programmes', items: ['Structured coding and robotics lessons', 'School clubs and extracurricular programmes', 'Training for primary and secondary learners', 'Institutional coding and robotics programmes'] },
  { icon: '⚙', title: 'Holiday Bootcamps', items: ['Practical coding and robotics sessions', 'Project-based learning', 'Interactive activities for children and young people', 'Opportunities to develop technology and innovation skills'] },
  { icon: '🎓', title: 'Teacher Training', items: ['Support for educators delivering coding and robotics lessons', 'Introduction to programming and robotics kits', 'Practical classroom project development'] },
]

export const CHESS_PROGRAMMES = [
  'Beginner chess lessons', 'Intermediate chess training', 'Chess training for schools and students', 'Tactical exercises and strategic thinking',
  'Interactive chess puzzles', 'School chess clubs', 'Chess workshops and friendly tournaments',
]

export const WHY = [
  ['🎛', 'Solutions tailored to customer needs'], ['📱', 'Modern and user-friendly designs'], ['🔧', 'Practical technology for everyday challenges'],
  ['🏫', 'Software products for businesses and schools'], ['🤖', 'Hands-on coding and robotics education'],
  ['♛', 'Chess training that encourages strategic thinking'], ['💬', 'Responsive communication and customer support'],
]

/**
 * PORTFOLIO: edit this list to add or update work.
 * To add a real project: put its screenshot in assets/portfolio/, then add an entry with
 *   image: 'assets/portfolio/my-site.webp'  (optionally link: 'https://...' and fit: 'contain' for tall images).
 */
export const CATEGORIES = ['Websites', 'Business Software', 'School Management', 'Point of Sale', 'Graphic Design', 'Coding & Robotics Projects', 'Chess Education']

export const PROJECTS = [
  { id: 'web-eduflow', title: 'EduFlow Website', category: 'Websites', image: 'assets/eduflow/home.webp', service: 'Website Development',
    description: 'The EduFlow home page: One School. One Flow. Everything Connected.',
    details: 'The public website for SwiftIQ EduFlow, introducing the school management system with clear sign-up and log-in actions.' },
  { id: 'biz-assistant', title: 'Business Assistant Landing Page', category: 'Business Software', image: 'assets/business/landing.webp', fit: 'contain', service: 'SwiftIQ Business Assistant',
    description: 'Run your business, serve customers, and let AI handle the rest.',
    details: 'The SwiftIQ Business Assistant landing page, introducing one dashboard for customers, sales, enquiries, appointments, and everyday operations, with an AI assistant that answers customer questions.' },
  { id: 'school-eduflow', title: 'EduFlow Dashboard', category: 'School Management', image: 'assets/eduflow/dashboard.webp', service: 'SwiftIQ EduFlow',
    description: 'Students, teachers, attendance, fees collected, and quick actions at a glance.',
    details: "The SwiftIQ EduFlow dashboard: student and teacher counts, today's attendance, fees collected, and shortcuts for common school tasks." },
  { id: 'school-academics', title: 'EduFlow Academics', category: 'School Management', image: 'assets/eduflow/academics.webp', service: 'SwiftIQ EduFlow',
    description: 'Classes and streams, subjects, academic years, and curricula.',
    details: 'The EduFlow academics module for managing classes and their streams, subjects, academic years, and curricula (CBC/CBE).' },
  { id: 'school-finance', title: 'EduFlow Finance', category: 'School Management', image: 'assets/eduflow/finance.webp', service: 'SwiftIQ EduFlow',
    description: 'Student accounts with invoices, payments, balances, and printable statements.',
    details: 'The EduFlow finance module: student accounts with invoiced and paid amounts in KES, balances, invoices, and payment history.' },
  { id: 'school-exams', title: 'EduFlow Exams & Assessments', category: 'School Management', image: 'assets/eduflow/exams.webp', service: 'SwiftIQ EduFlow',
    description: 'Assessments by class and subject, ready for score entry.',
    details: 'The EduFlow exams and assessments module for setting up assessments by class and subject and recording scores.' },
  { id: 'pos-dashboard', title: 'SwiftIQ POS Dashboard', category: 'Point of Sale', image: 'assets/pos/dashboard.webp', service: 'SwiftIQ POS',
    description: 'Sales, transactions, profit, customer balances, low stock, and cashier shifts.',
    details: 'The SwiftIQ POS dashboard with sales today, transactions, gross profit, customer balances, low-stock alerts, payment methods, and cashier shifts, plus a guided start for new businesses.' },
  { id: 'pos-checkout', title: 'SwiftIQ POS Checkout', category: 'Point of Sale', image: 'assets/pos/checkout.webp', service: 'SwiftIQ POS',
    description: 'Product search and barcode scanning, current sale, and payment selection.',
    details: 'The SwiftIQ POS checkout screen with product search, barcode scanning, categories, the current sale, and Cash, M-Pesa, or Card payment selection.' },
  { id: 'pos-mpesa', title: 'SwiftIQ POS M-Pesa Payment', category: 'Point of Sale', image: 'assets/pos/mpesa.webp', fit: 'contain', service: 'SwiftIQ POS',
    description: 'Customer prompt, approval status, and payment checking.',
    details: 'The M-Pesa payment step in SwiftIQ POS: the amount to pay, the customer phone number, and a status check while the customer approves the prompt on their own phone.' },
  { id: 'pos-signin', title: 'SwiftIQ POS Sign-in', category: 'Point of Sale', image: 'assets/pos/signin.webp', service: 'SwiftIQ POS',
    description: 'Smart Sales. Smarter Business.',
    details: 'The SwiftIQ POS sign-in page: checkout, stock, customers, and reports for every branch, in one place.' },
  { id: 'design-poster', title: 'Website Services Poster', category: 'Graphic Design', image: 'assets/graphic/website-flyer.webp', fit: 'contain', service: 'Graphic Design',
    description: 'A promotional poster for SwiftIQ website services.',
    details: 'A marketing poster for SwiftIQ Enterprise website services, showing the services offered and how to get in touch.' },
  { id: 'design-brand', title: 'SwiftIQ Brand Identity', category: 'Graphic Design', image: 'assets/logo.png', fit: 'contain', service: 'Graphic Design',
    description: 'The SwiftIQ Enterprise logo and colour system.',
    details: 'The SwiftIQ Enterprise logo and the midnight blue, electric blue, cyan, and violet palette used across the brand.' },
  { id: 'code-scratch', title: 'Scratch Programming', category: 'Coding & Robotics Projects', image: 'assets/robotics/scratch.webp', service: 'Coding & Robotics Training',
    description: 'Block-based programming with Scratch: sequences, loops, and decisions.',
    details: 'Learners build interactive projects with Scratch blocks, practising sequences, loops, variables, and decisions.' },
  { id: 'robot-arm', title: 'Robotic Arm Rover', category: 'Coding & Robotics Projects', image: 'assets/robotics/robot-arm-tank.webp', imageBg: 'light', fit: 'contain', service: 'Coding & Robotics Training',
    description: 'A tracked robot with a robotic arm and gripper.',
    details: 'A tracked robot with a robotic arm and gripper, used to learn about motors, assembly, and robotic control.' },
  { id: 'robot-sensor', title: 'Obstacle-Sensing Robot', category: 'Coding & Robotics Projects', image: 'assets/robotics/robot-tracked-sensor.webp', imageBg: 'light', fit: 'contain', service: 'Coding & Robotics Training',
    description: 'A tracked robot with an ultrasonic distance sensor.',
    details: 'A tracked robot fitted with an ultrasonic sensor, used to explore sensors, automation, and programming robot behaviour.' },
  { id: 'robot-microbit', title: 'micro:bit Mecanum Robot', category: 'Coding & Robotics Projects', image: 'assets/robotics/robot-microbit-mecanum.webp', imageBg: 'light', fit: 'contain', service: 'Coding & Robotics Training',
    description: 'A four-wheel mecanum robot driven by a micro:bit.',
    details: 'A four-wheel mecanum robot controlled by a micro:bit, used to learn programming, electronics, and robot control.' },
]

export const MODALS = {
  eduflow: { title: 'SwiftIQ EduFlow', cat: 'School Management System', service: 'SwiftIQ EduFlow',
    text: 'One system for your whole school: admissions and student records, academics, attendance, timetables, exams and assessments, finance, communication, reports, discipline, activities, staff, and documents. Suited to primary schools, secondary schools, and Cambridge schools.',
    btn: 'Ask about EduFlow', msg: 'I would like to learn more about SwiftIQ EduFlow for our school: ' },
  biz: { title: 'SwiftIQ Business Assistant', cat: 'Business Management Platform', service: 'SwiftIQ Business Assistant',
    text: 'One place to organise customers and products, track sales, prepare quotations and invoices, manage enquiries and follow-ups, schedule appointments, and review business analytics.',
    btn: 'Ask about Business Assistant', msg: 'I would like to learn more about SwiftIQ Business Assistant: ' },
  pos: { title: 'SwiftIQ POS', cat: 'Point of Sale System', service: 'SwiftIQ POS',
    text: 'Product search and barcode scanning, cart and checkout, Cash, M-Pesa, and card payment selection, receipts, sales records, inventory, purchases, customers, expenses, returns, reports, employees, and cashier shifts across every branch.',
    btn: 'Ask about SwiftIQ POS', msg: 'I would like to learn more about SwiftIQ POS: ' },
}
