import * as THREE from 'three'
import { createStage, mat, basic, mesh } from './stage.js'
import { makeBlocksTexture, makeSymbolTexture, makeSparkles } from './canvasArt.js'

export function startRobo(container, { low, reduced }) {
  const s = createStage(container, { low, reduced, fov: 38, camPos: [0, 2.6, 5.4], lookAt: [0, 0.2, 0] })
  const { scene, pointer } = s
  scene.add(new THREE.AmbientLight(0xffffff, 0.55))
  const d = new THREE.DirectionalLight(0xffffff, 1.3); d.position.set(3, 5, 4); scene.add(d)
  const c1 = new THREE.PointLight(0x00e5ff, 22, 12); c1.position.set(-3, 2, 2); scene.add(c1)
  const c2 = new THREE.PointLight(0x8b5cf6, 24, 12); c2.position.set(3, 3, -2); scene.add(c2)

  const rig = new THREE.Group(); scene.add(rig)
  const lab = new THREE.Group(); lab.position.y = -0.9; rig.add(lab)
  lab.add(mesh(new THREE.CylinderGeometry(3.1, 3.2, 0.16, 64), mat(0x0b1225, { metalness: 0.9, roughness: 0.25 }), [0, -0.08, 0]))
  lab.add(mesh(new THREE.RingGeometry(3.0, 3.06, 96), basic(0x00e5ff), [0, 0.001, 0], [-Math.PI / 2, 0, 0]))

  // Robot
  const robot = new THREE.Group(); robot.position.set(-1.1, 0.14, 0.4); lab.add(robot)
  robot.add(mesh(new THREE.BoxGeometry(0.8, 0.5, 0.6), mat(0xc9d3ea, { metalness: 0.8, roughness: 0.25 }), [0, 0.3, 0]))
  robot.add(mesh(new THREE.BoxGeometry(0.4, 0.2, 0.02), mat(0x00e5ff, { emissive: 0x00e5ff, emissiveIntensity: 1.4 }), [0, 0.3, 0.31]))
  ;[-0.42, 0.42].forEach((x) => robot.add(mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.12, 20), mat(0x1261ff, { metalness: 0.6, roughness: 0.35 }), [x, 0.08, 0], [0, 0, Math.PI / 2])))
  const head = new THREE.Group(); head.position.y = 0.72; robot.add(head)
  head.add(mesh(new THREE.BoxGeometry(0.55, 0.38, 0.45), mat(0xe8eefc, { metalness: 0.7, roughness: 0.25 })))
  ;[-0.12, 0.12].forEach((x) => head.add(mesh(new THREE.SphereGeometry(0.065, 16, 16), mat(0x8b5cf6, { emissive: 0x8b5cf6, emissiveIntensity: 2 }), [x, 0.02, 0.23])))
  head.add(mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.25, 8), mat(0xa7b4cc), [0, 0.3, 0]))
  head.add(mesh(new THREE.SphereGeometry(0.05, 12, 12), mat(0x00e5ff, { emissive: 0x00e5ff, emissiveIntensity: 2 }), [0, 0.45, 0]))

  // Robotic arm
  const arm = new THREE.Group(); arm.position.set(1.5, 0.05, -0.4); lab.add(arm)
  arm.add(mesh(new THREE.CylinderGeometry(0.4, 0.46, 0.14, 32), mat(0x0b1225, { metalness: 0.8, roughness: 0.3 }), [0, 0.07, 0]))
  const a = new THREE.Group(); a.position.y = 0.14; arm.add(a)
  a.add(mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.4, 20), mat(0x1261ff, { metalness: 0.7, roughness: 0.3 }), [0, 0.2, 0]))
  const b = new THREE.Group(); b.position.y = 0.4; a.add(b)
  b.add(mesh(new THREE.BoxGeometry(0.16, 0.9, 0.16), mat(0xd6def2, { metalness: 0.85, roughness: 0.25 }), [0, 0.45, 0]))
  const c = new THREE.Group(); c.position.y = 0.9; b.add(c)
  c.add(mesh(new THREE.BoxGeometry(0.13, 0.7, 0.13), mat(0x8b5cf6, { metalness: 0.7, roughness: 0.3 }), [0, 0.35, 0]))
  ;[-0.07, 0.07].forEach((x) => c.add(mesh(new THREE.BoxGeometry(0.04, 0.16, 0.1), mat(0x00e5ff, { emissive: 0x00e5ff, emissiveIntensity: 1 }), [x, 0.75, 0])))

  // Circuit board
  const board = new THREE.Group(); board.position.set(0.2, 0, 1.0); board.rotation.y = 0.2; lab.add(board)
  board.add(mesh(new THREE.BoxGeometry(2.1, 0.06, 1.8), mat(0x0f2a63, { metalness: 0.5, roughness: 0.5 })))
  ;[[[-0.7, 0.03, -0.8], [0.2, 0.03, -0.8], [0.2, 0.03, -0.2], [0.9, 0.03, -0.2]], [[-0.9, 0.03, -0.4], [-0.3, 0.03, -0.4], [-0.3, 0.03, 0.3]]].forEach((pts) => {
    board.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts.map((p) => new THREE.Vector3(...p))), new THREE.LineBasicMaterial({ color: 0x00e5ff })))
  })
  ;[[-0.6, 0.12, 0.4], [0.5, 0.12, 0.5], [0.2, 0.12, -0.5]].forEach((p) => board.add(mesh(new THREE.BoxGeometry(0.3, 0.12, 0.3), mat(0x10182e, { metalness: 0.6, roughness: 0.3 }), p)))

  // Laptop showing visual programming blocks
  const lap = new THREE.Group(); lap.position.set(-0.2, 0, -1.1); lap.rotation.y = 0.2; lab.add(lap)
  const metal = () => mat(0x8d97ad, { metalness: 0.95, roughness: 0.3 })
  lap.add(mesh(new THREE.BoxGeometry(1.9, 0.06, 1.2), metal(), [0, 0.04, 0]))
  const hinge = new THREE.Group(); hinge.position.set(0, 0.07, -0.58); hinge.rotation.x = -0.3; lap.add(hinge)
  hinge.add(mesh(new THREE.BoxGeometry(1.9, 1.17, 0.05), metal(), [0, 0.58, 0]))
  const screenMat = basic(0xffffff, { map: makeBlocksTexture() })
  hinge.add(mesh(new THREE.PlaneGeometry(1.7, 1.13), screenMat, [0, 0.58, 0.03]))
  new THREE.TextureLoader().load('assets/robotics/scratch.webp', (t) => { t.colorSpace = THREE.SRGBColorSpace; screenMat.map = t; screenMat.needsUpdate = true; s.render() })

  // Gears
  const gears = []
  const gear = (x, radius, teeth, speed, color) => {
    const outer = new THREE.Group(); outer.position.set(x, 0.35, -0.2); outer.rotation.x = Math.PI / 2; lab.add(outer)
    const inner = new THREE.Group(); outer.add(inner)
    const m = mat(color, { metalness: 0.85, roughness: 0.3 })
    inner.add(mesh(new THREE.CylinderGeometry(radius, radius, 0.14, 32), m))
    inner.add(mesh(new THREE.CylinderGeometry(radius * 0.28, radius * 0.28, 0.2, 16), mat(0x0b1225, { metalness: 0.5, roughness: 0.5 })))
    for (let i = 0; i < teeth; i++) {
      const ang = (i / teeth) * Math.PI * 2
      inner.add(mesh(new THREE.BoxGeometry(0.16, 0.14, 0.12), m, [Math.cos(ang) * (radius + 0.06), 0, Math.sin(ang) * (radius + 0.06)], [0, -ang, 0]))
    }
    gears.push({ inner, speed })
  }
  gear(-2.2, 0.5, 10, 0.9, 0x1261ff); gear(-1.12, 0.5, 10, -0.9, 0x8b5cf6)

  // Data pulse travelling between components
  const pulse = mesh(new THREE.SphereGeometry(0.06, 12, 12), basic(0x00e5ff)); lab.add(pulse)

  // Floating programming symbols
  const symbols = [['</>', [-1.6, 1.9, 0], 0x00e5ff], ['{ }', [1.8, 2.1, 0.2], 0x8b5cf6], ['if', [0.3, 2.4, -0.6], 0x1261ff], ['0101', [2.5, 0.9, 1], 0x00e5ff]].map(([t, p, col], i) => {
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: makeSymbolTexture(t, '#' + col.toString(16).padStart(6, '0')), transparent: true, toneMapped: false, depthWrite: false }))
    sp.position.set(...p); sp.scale.set(0.9, 0.45, 1); rig.add(sp); return { sp, y: p[1], ph: i * 1.7 }
  })
  const sparkles = makeSparkles(low ? 20 : 50, [7, 3.5, 5], 0x00e5ff, 0.08); rig.add(sparkles)

  s.onFrame((dt, t) => {
    head.rotation.y = Math.sin(t * 0.9) * 0.5
    robot.position.y = 0.14 + Math.sin(t * 2) * 0.03
    a.rotation.y = Math.sin(t * 0.6) * 0.6
    b.rotation.z = -0.5 + Math.sin(t * 1.1) * 0.45
    c.rotation.z = 0.9 + Math.sin(t * 1.5) * 0.4
    gears.forEach((g) => { g.inner.rotation.y += dt * g.speed })
    const k = (t * 0.35) % 1
    pulse.position.set(THREE.MathUtils.lerp(-0.5, 1.4, k), 0.35 + Math.sin(k * Math.PI) * 0.4, THREE.MathUtils.lerp(0.8, -0.3, k))
    symbols.forEach((o) => { o.sp.position.y = o.y + Math.sin(t * 1.6 + o.ph) * 0.12 })
    sparkles.rotation.y += dt * 0.03
    rig.rotation.y = THREE.MathUtils.lerp(rig.rotation.y, pointer.x * 0.35 - 0.15, 0.05)
    rig.rotation.x = THREE.MathUtils.lerp(rig.rotation.x, -pointer.y * 0.08, 0.05)
  })
  container.querySelector('.fallback-svg')?.remove()
  s.render()
}
