import { BRAND, SERVICE_OPTIONS, SERVICES, ROBO_PROGRAMMES, CHESS_PROGRAMMES, WHY, CATEGORIES, PROJECTS, MODALS } from './data.js'
import { createChess, GLYPH, NAME, squareName } from './chess-core.js'

const $ = (s, r = document) => r.querySelector(s)
const $$ = (s, r = document) => [...r.querySelectorAll(s)]
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches
const lowPower = (() => {
  const coarse = matchMedia('(pointer: coarse)').matches
  return (navigator.hardwareConcurrency ?? 8) <= 4 || (navigator.deviceMemory ?? 8) <= 2 || (coarse && innerWidth < 700)
})()
const webgl = (() => {
  try { const c = document.createElement('canvas'); return !!(window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl'))) } catch { return false }
})()
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))

const waLink = (t = '') => `https://wa.me/${BRAND.whatsapp}${t ? `?text=${encodeURIComponent(t)}` : ''}`
const mailLink = (subject = '', body = '') => `mailto:${BRAND.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`

function scrollToId(id) {
  const el = document.getElementById(id)
  if (!el) return
  el.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'start' })
  try { history.replaceState(null, '', '#' + id) } catch {}
}

/* ---------- static content from data ---------- */
$('#year').textContent = new Date().getFullYear()

$('#service-grid').innerHTML = SERVICES.map((s, i) => `
  <div class="tilt reveal d${i % 3}"><article class="service-card">
    <div class="service-card__media"><img src="${esc(s.images[0])}" alt="${esc(s.title)}" style="object-position:${s.pos}" loading="lazy" /></div>
    <h3>${esc(s.title)}</h3><p>${esc(s.text)}</p>
    <button class="btn btn-link" data-service="${i}" aria-label="Learn more about ${esc(s.title)}">Learn More</button>
  </article></div>`).join('')

$('#footer-services').innerHTML = SERVICES.map((s) => `<li><a href="#services">${esc(s.title)}</a></li>`).join('')
$('#robo-names').innerHTML = ROBO_PROGRAMMES.map((p) => `<li>${esc(p.title)}</li>`).join('')
$('#chess-names').innerHTML = CHESS_PROGRAMMES.map((p) => `<li>${esc(p)}</li>`).join('')
$('#robo-programmes').innerHTML = ROBO_PROGRAMMES.map((p) => `
  <div class="programme reveal"><span class="ico" style="font-size:1.6rem;margin-bottom:10px" aria-hidden="true">${p.icon}</span><h4>${esc(p.title)}</h4>
  <ul>${p.items.map((i) => `<li>${esc(i)}</li>`).join('')}</ul></div>`).join('')
$('#chess-programmes').innerHTML = CHESS_PROGRAMMES.map((p) => `<div class="programme programme--slim reveal"><span class="ico" aria-hidden="true">♟</span><h4>${esc(p)}</h4></div>`).join('')
$('#why-grid').innerHTML = WHY.map(([ic, t]) => `<div class="why-item reveal"><span class="why-item__icon" aria-hidden="true">${ic}</span><p>${esc(t)}</p></div>`).join('')
$('#f-service').insertAdjacentHTML('beforeend', SERVICE_OPTIONS.map((s) => `<option value="${esc(s)}">${esc(s)}</option>`).join(''))

// Links that need the contact details
$$('[data-wa]').forEach((a) => { a.href = waLink(a.dataset.wa) })
$$('[data-mail]').forEach((a) => { a.href = mailLink(a.dataset.mail) })

/* ---------- navigation ---------- */
const nav = $('#nav'), toggle = $('#nav-toggle'), menu = $('#mobile-menu')
const onScroll = () => nav.classList.toggle('nav--solid', scrollY > 40)
onScroll(); addEventListener('scroll', onScroll, { passive: true })

function setMenu(open) {
  toggle.setAttribute('aria-expanded', String(open))
  toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu')
  menu.hidden = !open
  menu.classList.toggle('is-open', open)
  document.body.style.overflow = open ? 'hidden' : ''
}
toggle.addEventListener('click', () => setMenu(toggle.getAttribute('aria-expanded') !== 'true'))
addEventListener('keydown', (e) => { if (e.key === 'Escape' && !menu.hidden) { setMenu(false); toggle.focus() } })
addEventListener('resize', () => { if (innerWidth > 1020 && !menu.hidden) setMenu(false) })

const navLinks = $$('.nav__links a')
const spy = new IntersectionObserver((es) => es.forEach((e) => {
  if (e.isIntersecting) navLinks.forEach((a) => { const on = a.getAttribute('href') === '#' + e.target.id; a.classList.toggle('is-active', on); on ? a.setAttribute('aria-current', 'true') : a.removeAttribute('aria-current') })
}), { rootMargin: '-45% 0px -50% 0px' })
;['home', 'services', 'products', 'portfolio', 'about', 'contact'].forEach((id) => spy.observe($('#' + id)))

/* ---------- global click handling ---------- */
function goToContact(service, message) {
  if (service !== undefined) $('#f-service').value = service
  if (message !== undefined && !$('#f-message').value.trim()) $('#f-message').value = message
  $('#form-status').textContent = ''
  scrollToId('contact')
}

document.addEventListener('click', (e) => {
  const a = e.target.closest('a[href^="#"]')
  if (a && a.getAttribute('href').length > 1) {
    const id = a.getAttribute('href').slice(1)
    if (document.getElementById(id)) { e.preventDefault(); setMenu(false); setTimeout(() => scrollToId(id), 30) }
    return
  }
  const sc = e.target.closest('[data-scroll]'); if (sc) { scrollToId(sc.dataset.scroll); return }
  const en = e.target.closest('[data-enquiry]')
  if (en) { setMenu(false); setTimeout(() => goToContact(en.dataset.enquiry, en.dataset.msg ?? `I would like to know more about ${en.dataset.enquiry}: `), 30); return }
  const mo = e.target.closest('[data-modal]'); if (mo) { openInfo(mo.dataset.modal); return }
  const sv = e.target.closest('[data-service]'); if (sv) openService(SERVICES[+sv.dataset.service])
})

/* ---------- reveal on scroll ---------- */
const revealEls = $$('.reveal')
if (reduced || !('IntersectionObserver' in window)) revealEls.forEach((el) => el.classList.add('in'))
else {
  const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target) } }), { rootMargin: '0px 0px -8% 0px', threshold: 0.05 })
  revealEls.forEach((el) => io.observe(el))
}

/* ---------- service card tilt (mouse only) ---------- */
$$('.tilt').forEach((t) => {
  const card = $('.service-card', t)
  t.addEventListener('pointermove', (e) => {
    if (e.pointerType !== 'mouse' || reduced) return
    const r = card.getBoundingClientRect(), px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height
    card.style.setProperty('--rx', `${(0.5 - py) * 9}deg`); card.style.setProperty('--ry', `${(px - 0.5) * 11}deg`)
    card.style.setProperty('--mx', `${px * 100}%`); card.style.setProperty('--my', `${py * 100}%`)
  })
  t.addEventListener('pointerleave', () => { card.style.setProperty('--rx', '0deg'); card.style.setProperty('--ry', '0deg') })
})

/* ---------- modal (native <dialog>: Esc, focus trap and focus return built in) ---------- */
const dlg = $('#modal'), body = $('#modal-body')
function openModal(html) { body.innerHTML = html; if (!dlg.open) dlg.showModal() }
dlg.addEventListener('click', (e) => { if (e.target === dlg || e.target.closest('[data-close]')) dlg.close() })
function openService(s) {
  openModal(`<h3 id="modal-title">${esc(s.title)}</h3><p>${esc(s.text)}</p>
    <div class="gallery">${s.images.map((src) => `<img src="${esc(src)}" alt="${esc(s.title)} example" loading="lazy" />`).join('')}</div>
    <div class="modal__actions"><button class="btn btn-primary" id="modal-go">Enquire about ${esc(s.title)}</button></div>`)
  $('#modal-go').onclick = () => { dlg.close(); goToContact(s.title, `I would like to know more about ${s.title}: `) }
}
function openInfo(key) {
  const m = MODALS[key]; if (!m) return
  openModal(`<h3 id="modal-title">${esc(m.title)}</h3><p class="tag"><span class="tag__cat">${esc(m.cat)}</span></p><p>${esc(m.text)}</p><div class="modal__actions"><button class="btn btn-primary" id="modal-go">${esc(m.btn)}</button>${m.link ? `<a class="btn btn-ghost" href="${esc(m.link)}" target="_blank" rel="noopener noreferrer">Visit EduFlow website</a>` : ''}</div>`)
  $('#modal-go').onclick = () => { dlg.close(); goToContact(m.service, m.msg) }
}

/* ---------- Screenshot tabs (EduFlow, POS) ---------- */
$$('.shot-tabs').forEach((tabs) => tabs.addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return
  $$('button', tabs).forEach((x) => { const on = x === b; x.classList.toggle('is-on', on); x.setAttribute('aria-selected', on) })
  const img = document.getElementById(tabs.dataset.img); img.src = b.dataset.src; img.alt = b.dataset.alt
}))

/* ---------- Chess: 2D board always works; 3D board replaces it when available ---------- */
const chess = createChess()
const chessBox = $('#chess-box')
function render2D({ pieces, sel, targets, last, check }) {
  chessBox.innerHTML = `<div class="chess2d" role="grid" aria-label="Chess board. You play White. Select a piece, then a highlighted square.">${
    Array.from({ length: 64 }, (_, i) => {
      const c = i % 8, r = Math.floor(i / 8), p = pieces.find((x) => x.c === c && x.r === r), on = p && p.id === sel
      const t = targets.find((x) => x.c === c && x.r === r)
      const isLast = last && ((last.from.c === c && last.from.r === r) || (last.to.c === c && last.to.r === r))
      const isCheck = check && check.c === c && check.r === r
      return `<button role="gridcell" class="sq ${(c + r) % 2 ? 'sq--dark' : ''} ${on ? 'is-sel' : ''} ${t ? (t.cap ? 'is-cap' : 'is-target') : ''} ${isLast ? 'is-last' : ''} ${isCheck ? 'is-check' : ''}" data-c="${c}" data-r="${r}" aria-label="${squareName(c, r)}${p ? `, ${p.color === 'w' ? 'white' : 'black'} ${NAME[p.type]}` : ', empty'}${on ? ', selected' : ''}${t ? ', legal move' : ''}">${p ? `<span class="${p.color === 'w' ? 'pc-w' : 'pc-b'}" aria-hidden="true">${GLYPH[p.color][p.type]}</span>` : ''}</button>`
    }).join('')}</div>`
}
let unsub2D = chess.subscribe(render2D)
chessBox.addEventListener('click', (e) => { const b = e.target.closest('.sq'); if (b) { const c = +b.dataset.c, r = +b.dataset.r; chess.click(c, r); $(`.sq[data-c="${c}"][data-r="${r}"]`)?.focus() } })
// status line, promotion picker and buttons (shared by the 2D and 3D boards)
chess.subscribe((st) => {
  $('#chess-status').textContent = st.status
  $('#chess-status').dataset.state = st.over ? 'over' : st.thinking ? 'thinking' : st.check ? 'check' : 'play'
  $('#chess-promo').hidden = !st.promo
  $('#chess-undo').disabled = !st.canUndo
})
$('#chess-reset').addEventListener('click', () => chess.reset())
$('#chess-undo').addEventListener('click', () => chess.undo())
$('#chess-level').addEventListener('change', (e) => chess.setLevel(e.target.value))
$('#chess-promo').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) chess.choosePromotion(b.dataset.t) })

/* ---------- 3D scenes (lazy, CDN Three.js; the page stays fully usable if they fail) ---------- */
const opts = { low: lowPower, reduced }
const conn = navigator.connection || {}
const slowNet = !!conn.saveData || /(^|-)[23]g$/.test(conn.effectiveType || '')
const isPhone = matchMedia('(pointer: coarse)').matches && innerWidth < 900
const weakDevice = (navigator.deviceMemory ?? 8) <= 2 || (matchMedia('(pointer: coarse)').matches && (navigator.hardwareConcurrency ?? 8) <= 4)
const lite = !webgl || slowNet || weakDevice // lite = skip WebGL, show the fast animated 2D hero
const idle = (fn) => ('requestIdleCallback' in window ? requestIdleCallback(fn, { timeout: 2500 }) : setTimeout(fn, 600))
const afterLoad = (fn) => (document.readyState === 'complete' ? idle(fn) : addEventListener('load', () => idle(fn), { once: true }))
if (lite) document.documentElement.classList.add('lite')
else {
  // 3D starts only after the page has painted and the browser is idle
  afterLoad(() => import('./hero.js').then((m) => m.startHero($('#hero-canvas'), opts)).catch((err) => console.warn('Hero 3D unavailable:', err)))
  const lazy = (el, fn) => new IntersectionObserver((es, o) => { if (es[0].isIntersecting) { o.disconnect(); fn() } }, { rootMargin: '250px' }).observe(el)
  lazy($('#robo-box'), () => import('./robo.js').then((m) => m.startRobo($('#robo-box'), opts)).catch((err) => console.warn('Robotics 3D unavailable:', err)))
  if (!isPhone) lazy(chessBox, () => import('./chess3d.js').then((m) => {
    unsub2D(); chessBox.className = 'scene-box scene-box--chess'; chessBox.innerHTML = ''
    chessBox.removeAttribute('role'); chessBox.setAttribute('aria-label', '3D chessboard. Tap a piece, then a square to move it.')
    m.startChess3D(chessBox, chess, opts)
  }).catch((err) => console.warn('Chess 3D unavailable:', err)))
}

/* ---------- Portfolio ---------- */
let activeCat = 'All'
const filters = $('#filters')
filters.innerHTML = ['All', ...CATEGORIES.filter((c) => PROJECTS.some((p) => p.category === c))].map((c) => `<button class="chip ${c === 'All' ? 'is-on' : ''}" aria-pressed="${c === 'All'}" data-cat="${esc(c)}">${esc(c)}</button>`).join('')
const thumb = (p) => `<img src="${esc(p.image)}" alt="${esc(p.title)}" class="preview-img ${p.fit === 'contain' ? 'is-contain' : 'is-cover'} ${p.imageBg === 'light' ? 'is-light' : ''}" loading="lazy" />`
function renderPortfolio() {
  const list = activeCat === 'All' ? PROJECTS : PROJECTS.filter((p) => p.category === activeCat)
  $('#portfolio-grid').innerHTML = list.map((p) => `<li class="project">
    <div class="project__img">${thumb(p)}</div>
    <div class="project__body"><p class="project__cat">${esc(p.category)}</p><h3>${esc(p.title)}</h3><p>${esc(p.description)}</p>
    <button class="btn btn-link" data-project="${p.id}" aria-label="View project: ${esc(p.title)}">View Project</button></div></li>`).join('')
}
renderPortfolio()
filters.addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return
  activeCat = b.dataset.cat
  $$('button', filters).forEach((x) => { x.classList.toggle('is-on', x === b); x.setAttribute('aria-pressed', x === b) })
  renderPortfolio()
})
$('#portfolio-grid').addEventListener('click', (e) => {
  const b = e.target.closest('[data-project]'); if (!b) return
  const p = PROJECTS.find((x) => x.id === b.dataset.project)
  openModal(`<div class="modal__img">${thumb(p)}</div><p class="tag"><span class="tag__cat">${esc(p.category)}</span></p>
    <h3 id="modal-title">${esc(p.title)}</h3><p>${esc(p.details)}</p>
    <div class="modal__actions"><button class="btn btn-primary" id="modal-go">Discuss a similar project</button>${p.link ? `<a class="btn btn-ghost" href="${esc(p.link)}" target="_blank" rel="noopener noreferrer">Visit live site</a>` : ''}</div>`)
  $('#modal-go').onclick = () => { dlg.close(); goToContact(p.service, `I am interested in a project like "${p.title}": `) }
})

/* ---------- Contact form: validation, then WhatsApp or the email app. Nothing is stored. ---------- */
const form = $('#enquiry')
function validate() {
  const v = { name: $('#f-name').value.trim(), email: $('#f-email').value.trim(), service: $('#f-service').value, message: $('#f-message').value.trim() }
  const err = {}
  if (v.name.length < 2) err.name = 'Enter your name.'
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email)) err.email = 'Enter a valid email address, for example name@example.com.'
  if (!v.service) err.service = 'Choose the service you are asking about.'
  if (v.message.length < 10) err.message = 'Describe your project in at least 10 characters.'
  ;['name', 'email', 'service', 'message'].forEach((k) => {
    const input = $('#f-' + k), p = $('#e-' + k)
    p.hidden = !err[k]; p.textContent = err[k] || ''
    input.setAttribute('aria-invalid', String(!!err[k])); err[k] ? input.setAttribute('aria-describedby', 'e-' + k) : input.removeAttribute('aria-describedby')
    input.closest('.field').classList.toggle('has-error', !!err[k])
  })
  return Object.keys(err).length ? null : v
}
function send(via) {
  const v = validate(), st = $('#form-status')
  if (!v) { st.textContent = 'Please fix the highlighted fields.'; return }
  const text = `Hello SwiftIQ Enterprise,\n\nName: ${v.name}\nEmail: ${v.email}\nService: ${v.service}\n\nProject details:\n${v.message}`
  if (via === 'whatsapp') { st.textContent = 'Opening WhatsApp with your enquiry ready to send. Press send in WhatsApp to finish.'; window.open(waLink(text), '_blank', 'noopener,noreferrer') }
  else { st.textContent = 'Opening your email app with your enquiry ready to send. Press send in your email app to finish.'; location.href = mailLink(`Enquiry: ${v.service}`, text) }
}
form.addEventListener('submit', (e) => { e.preventDefault(); send('whatsapp') })
$('#send-email').addEventListener('click', () => send('email'))
