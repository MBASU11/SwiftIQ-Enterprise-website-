# SwiftIQ Enterprise Website (plain HTML, CSS and JavaScript)

No build step, no Node, no npm. Just open it with VS Code **Live Server**.

## Run
1. Open this folder in VS Code.
2. Right-click `index.html` and choose **Open with Live Server** (or click **Go Live**).

The 3D scenes load Three.js from a CDN (jsdelivr), so an internet connection is needed for 3D and fonts. Without it the site still works and shows static fallbacks.

> Open it through Live Server (http://127.0.0.1:5500), not by double-clicking the file: browsers block JavaScript modules on file:// addresses.

## Edit
- `index.html`: page content and sections
- `css/styles.css`: styling and colours (variables at the top)
- `js/data.js`: contact number/email, services, programmes, portfolio projects
- `js/main.js`: interactions, forms, demos
- `js/hero.js`, `js/robo.js`, `js/chess3d.js`: the 3D scenes
- `assets/`: logo, EduFlow screenshots (`assets/eduflow`), robot photos (`assets/robotics`)

## Deploy
Upload the whole folder to Netlify (drag and drop), Cloudflare Pages, or GitHub Pages. No settings needed.

## Add real portfolio work
Put a screenshot in `assets/portfolio/`, then add an entry in `js/data.js` (see the comment above `PROJECTS`).
